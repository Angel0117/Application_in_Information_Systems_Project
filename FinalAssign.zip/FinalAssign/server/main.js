import { Meteor } from 'meteor/meteor';

/*
-Comment Header-
Austin Lee
Jacob Mulroy
Conner Hundt
D'Angelo Abell
*/

Meteor.startup(function() {
  // code to run on server at startup
 Future = Npm.require('fibers/future');
});

Meteor.methods({
UploadRecordByRecord:function(case_id, Hospital_code, Hospital_type_code, City_Code_Hospital, Hospital_region_code, Available, Department, Ward_Type, Ward_Facility_Code, BedGrade, patientID, City_Code_Patient, TypeOfAdmission, SeverityOfIllness, Visitors, age, Admission_Deposit, Stay){
	console.log("Inside UploadRecordByRecord");
	console.log(case_id);
	console.log(Stay);
	var http = require("http");
	var MongoClient = require("mongodb").MongoClient;
	var url = "mongodb://localhost:27017/";
	var future = new Future();
	MongoClient.connect(url, function(err, db){
		if (err) throw err;
		var dbo = db.db("Hospital");
		dbo.collection("info1").insertOne({"case_id": case_id, "Hospital_code": Hospital_code, "Hospital_type_code": Hospital_type_code, "City_Code_Hospital": City_Code_Hospital, "Hospital_region_code": Hospital_region_code,"Available": Available, "Department": Department, "Ward_Type": Ward_Type, "Ward_Facility_Code": Ward_Facility_Code, "BedGrade": BedGrade, "patientID": patientID, "City_Code_Patient": City_Code_Patient, "TypeOfAdmission": TypeOfAdmission, "SeverityOfIllness": SeverityOfIllness, "Visitors": Visitors, "age": age, "Admission_Deposit": Admission_Deposit, "Stay":Stay}) 
	});
return future.wait(); 
},

UploadBulk:function(event){
	console.log("Inside UploadBulk");
	//console.log(studentName);		

}

}) 
